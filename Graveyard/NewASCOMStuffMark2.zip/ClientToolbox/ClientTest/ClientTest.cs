using System;
using ASCOM.Interface.Focuser;
using ASCOM.Interface.Telescope;
using ASCOM.Helper;

namespace ASCOM
{
	class ClientTest
	{
		static void Main(string[] args)
		{
			string progID;

			Helper.Util U = new Helper.Util();

			// Could use Helper here but the Focuser Choose() is nice!
			progID = Focuser.Choose("FocusSim.Focuser");
			if (progID == "") return;
			Focuser F = new Focuser(progID);
			F.Link = true;
			Console.WriteLine("Connected to " + progID);
			Console.WriteLine("Current position is " + F.Position);
			Console.Write("New position: ");
			string sNewPos = Console.ReadLine();
			F.Move(Convert.ToInt32(sNewPos));
			while (F.IsMoving)
			{
			    Console.Write(".");
			    U.WaitForMilliseconds(333);
			}
			Console.WriteLine("\r\nMove complete. New position is " + F.Position.ToString());
			F.Link = false;

			progID = Telescope.Choose("ScopeSim.Telescope");
			if (progID == "") return;
			Telescope T = new Telescope(progID);
			T.Connected = true;
			Console.WriteLine("Connected to " + progID);
			Console.WriteLine("Current LST = " + T.SiderealTime);
			AxisRates AxR = T.AxisRates(TelescopeAxes.axisPrimary);
			Console.WriteLine(AxR.Count + " rates");
			if(AxR.Count == 0)
				Console.WriteLine("Empty AxisRates!");
			else
				foreach (Rate r in AxR)
					Console.WriteLine("Max=" + r.Maximum + " Min=" + r.Minimum);
			TrackingRates TrR = T.TrackingRates;
			if (TrR.Count == 0)
				Console.WriteLine("Empty TrackingRates!");
			else
				foreach (DriveRates dr in TrR)
					Console.WriteLine("DriveRate=" + dr);
			T.Connected = false;
			Console.Write("Press enter to quit");
			Console.ReadLine();
		}
	}
}
