using System;
using System.Windows.Forms;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.Runtime.Remoting.Channels.Http;
using ITestCSharpObjectInterfaces;


namespace ITestCSharpObjectInterfacesImpl01
{
	/// <summary>
	/// Summary description for TestCSharpObject01.
	/// </summary>
	public class TestCSharpObject01 : MarshalByRefObject, ITestCSharpObjectInterfaces.ITestCSharpObjectInterfaces
	{
		private string m_stringProperty;

		public TestCSharpObject01()
		{
			m_stringProperty = "";
			Console.WriteLine("TestCSharpObject01 constructor.");
		}

		public string stringProperty
		{
			get
			{
				return m_stringProperty;
			}

			set
			{
				m_stringProperty = value;
			}
		}

		public bool DisplayMessage (  )
		{
			if (m_stringProperty != "")
			{
				MessageBox.Show(m_stringProperty, "TestCSharpObject01");
				return true;
			}
			else
			{
				return false;
			}
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			//
			// TODO: Add code to start application here
			//
			string strChannelType = "TCP";
			int iPort = 9000;

			if (args.Length > 0)
			{
				for (int i = 0; i < args.Length; i++)
				{
					Console.Write("Argument : ");
					Console.WriteLine(args[i]);
				}

				strChannelType = args[0];
				iPort = Convert.ToInt32(args[1]);
			}

			if (strChannelType == "TCP")
			{
				TcpServerChannel tcp_channel = new TcpServerChannel(iPort);
				ChannelServices.RegisterChannel(tcp_channel);
			}
			else
			{
				HttpServerChannel http_channel = new HttpServerChannel(iPort);
				ChannelServices.RegisterChannel(http_channel);
			}

			ActivatedServiceTypeEntry remObj = new ActivatedServiceTypeEntry(typeof(TestCSharpObject01));

			string strApplicationName = "TestCSharpObject01";

			RemotingConfiguration.ApplicationName = strApplicationName;
			RemotingConfiguration.RegisterActivatedServiceType(remObj);

			Console.WriteLine("Press [ENTER] to exit.");

			Console.ReadLine();
		}
	}
}
