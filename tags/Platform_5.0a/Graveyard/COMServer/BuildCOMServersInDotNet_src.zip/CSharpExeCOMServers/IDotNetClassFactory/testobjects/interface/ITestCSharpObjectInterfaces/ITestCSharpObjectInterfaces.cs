using System;

namespace ITestCSharpObjectInterfaces
{
	/// <summary>
	/// Summary description for ITestCSharpObjectInterfaces.
	/// </summary>
	public interface ITestCSharpObjectInterfaces
	{
		string stringProperty
		{
			get;
			set;
		}

		bool DisplayMessage();
	}
}
