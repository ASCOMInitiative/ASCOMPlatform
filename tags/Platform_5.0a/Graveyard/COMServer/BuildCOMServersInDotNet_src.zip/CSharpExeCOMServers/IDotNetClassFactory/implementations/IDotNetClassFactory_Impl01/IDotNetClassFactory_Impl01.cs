using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.Runtime.Remoting.Channels.Http;
using System.Runtime.Remoting.Activation;
using IDotNetClassFactory;


namespace IDotNetClassFactory_Impl01
{
	/// <summary>
	/// Summary description for IDotNetClassFactory_Impl01.
	/// </summary>
	public class IDotNetClassFactory_Impl01 : IDotNetClassFactory.IDotNetClassFactory
	{
		public IDotNetClassFactory_Impl01()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public object CreateInstance_ByActivation(string strAssemblyName, string strTypeName)
		{
			ObjectHandle				object_handle = null;
			object						objRet = null;

			// During the following call to Activator.CreateInstance(), the constructor of the class that 
			// implements the type indicated in strTypeName will be invoked.
			object_handle = Activator.CreateInstanceFrom
				(
				strAssemblyName,
				strTypeName
				);

			// Unwrap the delivered object and cast it to the "object" type.
			objRet = (object)(object_handle.Unwrap());

			return objRet;
		}

		public object CreateInstance_ByReflection(string strAssemblyName, string strTypeName)
		{
			Assembly					assembly;
			object						objRet = null;

			assembly = Assembly.LoadFrom(strAssemblyName); 

			// During the following call to Activator.CreateInstance(), the constructor of the class that 
			// implements the type indicated in strTypeName will be invoked.
			objRet = assembly.CreateInstance
				(
				strTypeName
				);

			return objRet;
		}

		public 	object CreateInstance_ByRemoting
		(
		  string strAssemblyName, 
		  string strTypeName, 
		  string strURL, 
		  bool bExecute, 
		  string strAssemblyFullPath,
		  string strArgumentString
		)
		{
			UrlAttribute[]				attr = { new UrlAttribute(strURL) };
			ObjectHandle				object_handle = null;
			object						objRet = null;

			if (bExecute)
			{
			  Process.Start(strAssemblyFullPath, strArgumentString);
			}

			// Create a client tcp channel from which to receive the Remote Object.
			TcpClientChannel tcp_channel = new TcpClientChannel();
			// Register the channel.
			ChannelServices.RegisterChannel(tcp_channel);
			// Create a client http channel from which to receive the Remote Object.
			HttpClientChannel http_channel = new HttpClientChannel();
			// Register the channel.
			ChannelServices.RegisterChannel(http_channel);

			// During the following call to Activator.CreateInstance(), the constructor of the class that 
			// implements the type indicated in strTypeName will be invoked.
			object_handle = Activator.CreateInstance
				(
				strAssemblyName,
				strTypeName,
				attr
				);

			// Unwrap the delivered object and cast it to the "object" type.
			objRet = (object)(object_handle.Unwrap());

			return objRet;
		}
	}
}
