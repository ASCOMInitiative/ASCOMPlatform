using System;

namespace IDotNetClassFactory
{
	/// <summary>
	/// Summary description for IDotNetClassFactory.
	/// </summary>
	public interface IDotNetClassFactory
	{
		object CreateInstance_ByActivation(string strAssemblyName, string strTypeName);
		object CreateInstance_ByReflection(string strAssemblyName, string strTypeName);
		object CreateInstance_ByRemoting
			   (
			      string strAssemblyName, 
			      string strTypeName, 
			      string strURL, 
			      bool bExecute, 
			      string strAssemblyFullPath,
			      string strArgumentString
			    );
	}
}
