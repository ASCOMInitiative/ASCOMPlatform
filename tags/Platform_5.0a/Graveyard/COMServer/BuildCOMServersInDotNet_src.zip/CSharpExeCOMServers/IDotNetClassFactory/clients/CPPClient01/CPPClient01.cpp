// CPPClient01.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#import "IDotNetClassFactory.tlb" raw_interfaces_only // For definition of the IDotNetClassFactory interface.
using namespace IDotNetClassFactory;
#import "TestCSharpObjectInterfaces.tlb"  // For definition of the TestCSharpObjectInterfaces interfaces.
using namespace TestCSharpObjectInterfaces;

// Generic CreateInstance() templated function to help in generic object creation.
template <class SmartPtrClass>
bool CreateInstance(LPCTSTR lpszProgID, SmartPtrClass& spSmartPtrReceiver, DWORD dwClsContext = CLSCTX_ALL)
{
  HRESULT			hrRetTemp = S_OK;
  _bstr_t			bstProgID(lpszProgID);
  CLSID				clsid;
  bool				bRet = false;
  
  hrRetTemp = CLSIDFromProgID
  (
    (LPCOLESTR)bstProgID,  //Pointer to the ProgID
    (LPCLSID)&clsid         //Pointer to the CLSID
  );

  if (hrRetTemp == S_OK)
  {
    if (SUCCEEDED(spSmartPtrReceiver.CreateInstance(clsid, NULL, dwClsContext)))
    {
	  bRet = true;
	}
	else
	{
	  bRet = false;
	}
  }

  return bRet;
}





void Demonstrate_CreationInstance_ByActivation(IDotNetClassFactoryPtr& spIDotNetClassFactory)
{
  _bstr_t							_bstrAssemblyName("..\\..\\testobjects"
"\\implementations\\ITestCSharpObjectInterfacesImpl01"
"\\bin\\Debug\\ITestCSharpObjectInterfacesImpl01.exe");
  _bstr_t							_bstrTypeName("ITestCSharpObjectInterfacesImpl01.TestCSharpObject01");
  VARIANT							varRet;
  ITestCSharpObjectInterfacesPtr	spITestCSharpObjectInterfaces = NULL;
  
  VariantInit(&varRet);
  VariantClear(&varRet);
  
  spIDotNetClassFactory -> CreateInstance_ByActivation
  (
    (BSTR)_bstrAssemblyName,
    (BSTR)_bstrTypeName,
    &varRet
  );
  
  if ((V_VT(&varRet) != VT_EMPTY) && (V_UNKNOWN(&varRet) != NULL))
  {
    V_UNKNOWN(&varRet) -> QueryInterface(__uuidof(ITestCSharpObjectInterfacesPtr), (void**)&spITestCSharpObjectInterfaces);
  }
  
  if (spITestCSharpObjectInterfaces)
  {
    spITestCSharpObjectInterfaces -> put_stringProperty(_bstr_t("Hello .NET World. Created using IDotNetClassFactory.CreateInstance_ByActivation()"));
    spITestCSharpObjectInterfaces -> DisplayMessage();
  }

  return;
}





void Demonstrate_CreationInstance_ByReflection(IDotNetClassFactoryPtr& spIDotNetClassFactory)
{
  _bstr_t							_bstrAssemblyName("..\\..\\testobjects"
"\\implementations\\ITestCSharpObjectInterfacesImpl01"
"\\bin\\Debug\\ITestCSharpObjectInterfacesImpl01.exe");
  _bstr_t							_bstrTypeName("ITestCSharpObjectInterfacesImpl01.TestCSharpObject01");
  VARIANT							varRet;
  ITestCSharpObjectInterfacesPtr	spITestCSharpObjectInterfaces = NULL;
  
  VariantInit(&varRet);
  VariantClear(&varRet);
  
  spIDotNetClassFactory -> CreateInstance_ByReflection
  (
    (BSTR)_bstrAssemblyName,
    (BSTR)_bstrTypeName,
    &varRet
  );
  
  if ((V_VT(&varRet) != VT_EMPTY) && (V_UNKNOWN(&varRet) != NULL))
  {
    V_UNKNOWN(&varRet) -> QueryInterface(__uuidof(ITestCSharpObjectInterfacesPtr), (void**)&spITestCSharpObjectInterfaces);
  }
  
  if (spITestCSharpObjectInterfaces)
  {
    spITestCSharpObjectInterfaces -> put_stringProperty(_bstr_t("Hello .NET World. Created using IDotNetClassFactory.CreateInstance_ByReflection()"));
    spITestCSharpObjectInterfaces -> DisplayMessage();
  }

  return;
}





void Demonstrate_CreationInstance_ByRemoting(IDotNetClassFactoryPtr& spIDotNetClassFactory)
{
  _bstr_t							_bstrAssemblyName("ITestCSharpObjectInterfacesImpl01");
  _bstr_t							_bstrTypeName("ITestCSharpObjectInterfacesImpl01.TestCSharpObject01");
  _bstr_t							_bstrURL("tcp://localhost:7000/TestCSharpObject01");
  _bstr_t							_bstrAssemblyFullPath
  ("..\\..\\testobjects"
   "\\implementations\\ITestCSharpObjectInterfacesImpl01"
   "\\bin\\Debug\\ITestCSharpObjectInterfacesImpl01.exe"
  );
  _bstr_t							_bstrArgumentString("TCP 7000");
  VARIANT							varRet;
  ITestCSharpObjectInterfacesPtr	spITestCSharpObjectInterfaces = NULL;
  
  VariantInit(&varRet);
  VariantClear(&varRet);
  
  spIDotNetClassFactory -> CreateInstance_ByRemoting
  (
    (BSTR)_bstrAssemblyName,
    (BSTR)_bstrTypeName,
    (BSTR)_bstrURL,
    VARIANT_TRUE,  // VARIANT_FALSE simulates REGCLS_MULTIPLEUSE. VARIANT_TRUE (with an appropriately set new Port number) simulates REGCLS_SINGLEUSE.
    (BSTR)_bstrAssemblyFullPath,
    (BSTR)_bstrArgumentString,
    &varRet
  );
  
  if ((V_VT(&varRet) != VT_EMPTY) && (V_UNKNOWN(&varRet) != NULL))
  {
    V_UNKNOWN(&varRet) -> QueryInterface(__uuidof(ITestCSharpObjectInterfacesPtr), (void**)&spITestCSharpObjectInterfaces);
  }
  
  if (spITestCSharpObjectInterfaces)
  {
    spITestCSharpObjectInterfaces -> put_stringProperty(_bstr_t("Hello .NET World. Created using IDotNetClassFactory.CreateInstance_ByRemoting()"));
    spITestCSharpObjectInterfaces -> DisplayMessage();
  }

  return;
}





int _tmain(int argc, _TCHAR* argv[])
{
    ::CoInitialize(NULL);
    
    if (1)
    {
      IDotNetClassFactoryPtr spIDotNetClassFactory;
      
      // First instantiate a IDotNetClassFactory implementation.
      CreateInstance<IDotNetClassFactoryPtr>("IDotNetClassFactory_Impl01.IDotNetClassFactory_Impl01", spIDotNetClassFactory);
      
      // Demonstrate the creation of a .NET object via 
      // IDotNetClassFactory.CreateInstance_ByActivation().
      Demonstrate_CreationInstance_ByActivation(spIDotNetClassFactory);      

      // Demonstrate the creation of a .NET object via 
      // IDotNetClassFactory.CreateInstance_ByReflection().
      Demonstrate_CreationInstance_ByReflection(spIDotNetClassFactory);      

      // Demonstrate the creation of a .NET object via 
      // IDotNetClassFactory.CreateInstance_ByRemoting().
      Demonstrate_CreationInstance_ByRemoting(spIDotNetClassFactory);            
    }
    
    ::CoUninitialize();
    
	return 0;
}

