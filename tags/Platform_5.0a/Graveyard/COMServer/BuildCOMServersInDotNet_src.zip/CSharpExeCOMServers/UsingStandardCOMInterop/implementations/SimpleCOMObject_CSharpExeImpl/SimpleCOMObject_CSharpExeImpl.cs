using System;
using System.Text;
using System.Windows.Forms;  // For using MessageBox.
using Interop.SimpleCOMObject; // In order to implement ISimpleCOMObject.

namespace SimpleCOMObject_CSharpExeImpl
{
	public class SimpleCOMObject : ISimpleCOMObject
	{
		private int m_iLongProperty;
	    
		public SimpleCOMObject()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		
		public int LongProperty
		{
			get
			{
				return m_iLongProperty;
			}
		  
			set
			{
				m_iLongProperty = value;
			}
		}
		
		public void Method01 (String strMessage)
		{
			StringBuilder sb = new StringBuilder(strMessage);
		  
			sb.Append(LongProperty.ToString());
		  
			MessageBox.Show(sb.ToString(), "SimpleCOMObject_CSharpExeImpl.SimpleCOMObject");
		}
	}

	/// <summary>
	/// Summary description for SimpleCOMObject_CSharpExeImpl.
	/// </summary>
	class SimpleCOMObject_CSharpExeImpl
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			//
			// TODO: Add code to start application here
			//
			int i;
			int iCount = args.Length;

			for (i = 0; i < iCount; i++)
			{
				Console.Write ("Argument : ");
				Console.WriteLine (args[i]);
			}

			Console.WriteLine("Press [ENTER] to exit.");
			Console.ReadLine();
		}
	}
}
