// CPPClient01.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#import "SimpleCOMObject.tlb"
using namespace SimpleCOMObjectLib;

// Generic CreateInstance() templated function to help in generic object creation.
template <class SmartPtrClass>
bool CreateInstance(LPCTSTR lpszProgID, SmartPtrClass& spSmartPtrReceiver, DWORD dwClsContext = CLSCTX_ALL)
{
  HRESULT			hrRetTemp = S_OK;
  _bstr_t			bstProgID(lpszProgID);
  CLSID				clsid;
  bool				bRet = false;
  
  hrRetTemp = CLSIDFromProgID
  (
    (LPCOLESTR)bstProgID,  //Pointer to the ProgID
    (LPCLSID)&clsid         //Pointer to the CLSID
  );

  if (hrRetTemp == S_OK)
  {
    if (SUCCEEDED(spSmartPtrReceiver.CreateInstance(clsid, NULL, dwClsContext)))
    {
	  bRet = true;
	}
	else
	{
	  bRet = false;
	}
  }

  return bRet;
}

int _tmain(int argc, _TCHAR* argv[])
{
  ::CoInitialize(NULL);
  
  if (1)
  {
	// ISimpleCOMObjectPtr is a smart pointer class which will manage 
	// a pointer to the COM interface ISimpleCOMObject for us.
    ISimpleCOMObjectPtr	spISimpleCOMObject_CSharpExeImpl = NULL;

	// We create an instance of an implementation of the ISimpleCOMObject interface
	// as provided by the COM class whose CLSID is synonymous
	// with the ProgID "SimpleCOMObject_CSharpExeImpl.SimpleCOMObject".
	CreateInstance<ISimpleCOMObjectPtr>("SimpleCOMObject_CSharpExeImpl.SimpleCOMObject", spISimpleCOMObject_CSharpExeImpl, CLSCTX_INPROC_SERVER /* CLSCTX_LOCAL_SERVER */);
	
	if (spISimpleCOMObject_CSharpExeImpl)
	{
	  spISimpleCOMObject_CSharpExeImpl -> put_LongProperty(1000);
	  spISimpleCOMObject_CSharpExeImpl -> Method01(_bstr_t("C# Exe Implementation. The Long Property Value Is : "));
	}
  }
  
  ::CoUninitialize(); 

  return 0;
}

