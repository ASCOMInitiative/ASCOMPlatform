// CPPClient01.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#import "SimpleCOMObject.tlb" raw_interfaces_only
using namespace SimpleCOMObjectLib;

// Generic CreateInstance() templated function to help in generic object creation.
template <class SmartPtrClass>
bool CreateInstance(LPCTSTR lpszProgID, SmartPtrClass& spSmartPtrReceiver, DWORD dwClsContext = CLSCTX_ALL)
{
  HRESULT			hrRetTemp = S_OK;
  _bstr_t			bstProgID(lpszProgID);
  CLSID				clsid;
  bool				bRet = false;
  
  hrRetTemp = CLSIDFromProgID
  (
    (LPCOLESTR)bstProgID,  //Pointer to the ProgID
    (LPCLSID)&clsid         //Pointer to the CLSID
  );

  if (hrRetTemp == S_OK)
  {
    if (SUCCEEDED(spSmartPtrReceiver.CreateInstance(clsid, NULL, dwClsContext)))
    {
	  bRet = true;
	}
	else
	{
	  bRet = false;
	}
  }

  return bRet;
}





// Generic CreateInstanceByClassFactory() templated function to help in 
// generic object creation. The class factory of the coclass is used to 
// create the instance.
template <class SmartPtrClass>
bool CreateInstanceByClassFactory
(
  LPCTSTR lpszProgID, 
  SmartPtrClass& spSmartPtrReceiver,
  IClassFactoryPtr& spIClassFactoryPtrReceiver,
  DWORD dwClsContext = CLSCTX_ALL
)
{
  HRESULT			hrRetTemp = S_OK;
  _bstr_t			bstProgID(lpszProgID);
  CLSID				clsid;
  bool				bRet = false;
  
  hrRetTemp = CLSIDFromProgID
  (
    (LPCOLESTR)bstProgID,  //Pointer to the ProgID
    (LPCLSID)&clsid         //Pointer to the CLSID
  );

  if (hrRetTemp == S_OK)
  {
    CoGetClassObject
    (
      (REFCLSID)clsid,  //CLSID associated with the class object
      (DWORD)dwClsContext, //Context for running executable code
      (COSERVERINFO*)NULL, //Pointer to machine on which the object is to be instantiated
      (REFIID)IID_IClassFactory,      //Reference to the identifier of the interface
      (LPVOID *)&spIClassFactoryPtrReceiver      //Address of output variable that receives the 
                    // interface pointer requested in riid
    );  
  }
  
  if (spIClassFactoryPtrReceiver)
  {
    hrRetTemp = spIClassFactoryPtrReceiver -> CreateInstance
    (
      NULL, 
      __uuidof(SmartPtrClass), 
      (LPVOID *)&spSmartPtrReceiver
    );
    
    if (SUCCEEDED(hrRetTemp))
    {
      bRet = true;
    }
    else
    {
      bRet = false;
    }
  }

  return bRet;
}





int _tmain(int argc, _TCHAR* argv[])
{
  ::CoInitialize(NULL);
  
  if (1)
  {
	// ISimpleCOMObjectPtr is a smart pointer class which will manage 
	// a pointer to the COM interface ISimpleCOMObject for us.
    ISimpleCOMObjectPtr	spISimpleCOMObject1 = NULL;
    ISimpleCOMObjectPtr	spISimpleCOMObject2 = NULL;
    IClassFactoryPtr	spIClassFactory = NULL;

	// We create an instance of the class factory of the coclass
	// whose CLSID is synonymous with the ProgID 
	// "ManagedCOMLocalServer_Impl01.SimpleCOMObject".
	// From this class factory object, we will also create an 
	// instance of the above-mentioned coclass and get hold of
	// its ISimpleCOMObject interface.
	CreateInstanceByClassFactory<ISimpleCOMObjectPtr>
    (
      "ManagedCOMLocalServer_Impl01.SimpleCOMObject", 
      spISimpleCOMObject1,
      spIClassFactory,
      CLSCTX_LOCAL_SERVER
    );
    
    if (spIClassFactory)
    {
      spIClassFactory -> LockServer(TRUE);
    }
    
	if (spISimpleCOMObject1)
	{
	  spISimpleCOMObject1 -> put_LongProperty(1002);
	  spISimpleCOMObject1 -> Method01(_bstr_t("C# EXE Local Server. The Long Property Value Is : "));
	  // Next Release() spISimpleCOMObject1.
	  spISimpleCOMObject1 = NULL;
	}    

	// We create an instance of an implementation of the ISimpleCOMObject interface
	// as provided by the COM class whose CLSID is synonymous
	// with the ProgID "ManagedCOMLocalServer_Impl01.SimpleCOMObject".
	CreateInstance<ISimpleCOMObjectPtr>
	(
	  "ManagedCOMLocalServer_Impl01.SimpleCOMObject", 
	  spISimpleCOMObject2, 
	  /*CLSCTX_INPROC_SERVER*/ CLSCTX_LOCAL_SERVER
	);
		
	if (spISimpleCOMObject2)
	{
	  spISimpleCOMObject2 -> put_LongProperty(1002);
	  spISimpleCOMObject2 -> Method01(_bstr_t("C# EXE Local Server. The Long Property Value Is : "));
	  spISimpleCOMObject2 = NULL;
	}
		
    if (spIClassFactory)
    {
      spIClassFactory -> LockServer(FALSE);
      spIClassFactory = NULL;
    }
  }

  ::CoUninitialize();
  
  return 0;
}

