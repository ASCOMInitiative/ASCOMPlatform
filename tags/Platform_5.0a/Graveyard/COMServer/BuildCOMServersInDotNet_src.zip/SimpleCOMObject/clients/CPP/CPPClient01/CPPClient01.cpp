// CPPClient01.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#import "SimpleCOMObject.tlb"
using namespace SimpleCOMObjectLib;

// Generic CreateInstance() templated function to help in generic object creation.
template <class SmartPtrClass>
bool CreateInstance(LPCTSTR lpszProgID, SmartPtrClass& spSmartPtrReceiver, DWORD dwClsContext = CLSCTX_ALL)
{
  HRESULT			hrRetTemp = S_OK;
  _bstr_t			bstProgID(lpszProgID);
  CLSID				clsid;
  bool				bRet = false;
  
  hrRetTemp = CLSIDFromProgID
  (
    (LPCOLESTR)bstProgID,  //Pointer to the ProgID
    (LPCLSID)&clsid         //Pointer to the CLSID
  );

  if (hrRetTemp == S_OK)
  {
    if (SUCCEEDED(spSmartPtrReceiver.CreateInstance(clsid, NULL, dwClsContext)))
    {
	  bRet = true;
	}
	else
	{
	  bRet = false;
	}
  }

  return bRet;
}

int _tmain(int argc, _TCHAR* argv[])
{
  ::CoInitialize(NULL);
  
  if (1)
  {
	// ISimpleCOMObjectPtr is a smart pointer class which will manage 
	// a pointer to the COM interface ISimpleCOMObject for us.
    ISimpleCOMObjectPtr spISimpleCOMObject_CPPImpl = NULL;
    ISimpleCOMObjectPtr	spISimpleCOMObject_CSharpImpl = NULL;

	// We create an instance of an implementation of the ISimpleCOMObject interface
	// as provided by the COM class whose CLSID is synonymous
	// with the ProgID "SimpleCOMObject_CPPImpl.SimpleCOMObject".
	CreateInstance<ISimpleCOMObjectPtr>("SimpleCOMObject_CPPImpl.SimpleCOMObject", spISimpleCOMObject_CPPImpl);

	// We create an instance of an implementation of the ISimpleCOMObject interface
	// as provided by the COM class whose CLSID is synonymous
	// with the ProgID "SimpleCOMObject_CSharpImpl.SimpleCOMObject".
	CreateInstance<ISimpleCOMObjectPtr>("SimpleCOMObject_CSharpImpl.SimpleCOMObject", spISimpleCOMObject_CSharpImpl);
	
	spISimpleCOMObject_CPPImpl -> put_LongProperty(1000);
	spISimpleCOMObject_CPPImpl -> Method01(_bstr_t("CPP Implementation. The Long Property Value Is : "));
	
	spISimpleCOMObject_CSharpImpl -> put_LongProperty(1000);
	spISimpleCOMObject_CSharpImpl -> Method01(_bstr_t("C# Implementation. The Long Property Value Is : "));
  }
  
  ::CoUninitialize(); 

  return 0;
}

