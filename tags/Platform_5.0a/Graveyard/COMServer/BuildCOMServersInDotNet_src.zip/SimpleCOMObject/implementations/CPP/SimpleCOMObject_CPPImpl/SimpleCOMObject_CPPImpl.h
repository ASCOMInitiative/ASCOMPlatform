

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 6.00.0361 */
/* at Thu Jan 05 00:56:24 2006
 */
/* Compiler settings for .\SimpleCOMObject_CPPImpl.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __SimpleCOMObject_CPPImpl_h__
#define __SimpleCOMObject_CPPImpl_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __ISimpleCOMObject_CPPImpl_FWD_DEFINED__
#define __ISimpleCOMObject_CPPImpl_FWD_DEFINED__
typedef interface ISimpleCOMObject_CPPImpl ISimpleCOMObject_CPPImpl;
#endif 	/* __ISimpleCOMObject_CPPImpl_FWD_DEFINED__ */


#ifndef ___ISimpleCOMObject_CPPImplEvents_FWD_DEFINED__
#define ___ISimpleCOMObject_CPPImplEvents_FWD_DEFINED__
typedef interface _ISimpleCOMObject_CPPImplEvents _ISimpleCOMObject_CPPImplEvents;
#endif 	/* ___ISimpleCOMObject_CPPImplEvents_FWD_DEFINED__ */


#ifndef __SimpleCOMObject_CPPImpl_FWD_DEFINED__
#define __SimpleCOMObject_CPPImpl_FWD_DEFINED__

#ifdef __cplusplus
typedef class SimpleCOMObject_CPPImpl SimpleCOMObject_CPPImpl;
#else
typedef struct SimpleCOMObject_CPPImpl SimpleCOMObject_CPPImpl;
#endif /* __cplusplus */

#endif 	/* __SimpleCOMObject_CPPImpl_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"
#include "SimpleCOMObject.h"

#ifdef __cplusplus
extern "C"{
#endif 

void * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void * ); 

#ifndef __ISimpleCOMObject_CPPImpl_INTERFACE_DEFINED__
#define __ISimpleCOMObject_CPPImpl_INTERFACE_DEFINED__

/* interface ISimpleCOMObject_CPPImpl */
/* [unique][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_ISimpleCOMObject_CPPImpl;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("F990BAEB-4380-4A28-A4A8-2F30A571B195")
    ISimpleCOMObject_CPPImpl : public IDispatch
    {
    public:
    };
    
#else 	/* C style interface */

    typedef struct ISimpleCOMObject_CPPImplVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISimpleCOMObject_CPPImpl * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISimpleCOMObject_CPPImpl * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISimpleCOMObject_CPPImpl * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISimpleCOMObject_CPPImpl * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISimpleCOMObject_CPPImpl * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISimpleCOMObject_CPPImpl * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISimpleCOMObject_CPPImpl * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        END_INTERFACE
    } ISimpleCOMObject_CPPImplVtbl;

    interface ISimpleCOMObject_CPPImpl
    {
        CONST_VTBL struct ISimpleCOMObject_CPPImplVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISimpleCOMObject_CPPImpl_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISimpleCOMObject_CPPImpl_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISimpleCOMObject_CPPImpl_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISimpleCOMObject_CPPImpl_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISimpleCOMObject_CPPImpl_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISimpleCOMObject_CPPImpl_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISimpleCOMObject_CPPImpl_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __ISimpleCOMObject_CPPImpl_INTERFACE_DEFINED__ */



#ifndef __SimpleCOMObject_CPPImplLib_LIBRARY_DEFINED__
#define __SimpleCOMObject_CPPImplLib_LIBRARY_DEFINED__

/* library SimpleCOMObject_CPPImplLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_SimpleCOMObject_CPPImplLib;

#ifndef ___ISimpleCOMObject_CPPImplEvents_DISPINTERFACE_DEFINED__
#define ___ISimpleCOMObject_CPPImplEvents_DISPINTERFACE_DEFINED__

/* dispinterface _ISimpleCOMObject_CPPImplEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__ISimpleCOMObject_CPPImplEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("DF7FD692-A598-4AD8-A59E-AE0E3E65BD1C")
    _ISimpleCOMObject_CPPImplEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _ISimpleCOMObject_CPPImplEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            _ISimpleCOMObject_CPPImplEvents * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            _ISimpleCOMObject_CPPImplEvents * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            _ISimpleCOMObject_CPPImplEvents * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            _ISimpleCOMObject_CPPImplEvents * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            _ISimpleCOMObject_CPPImplEvents * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            _ISimpleCOMObject_CPPImplEvents * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            _ISimpleCOMObject_CPPImplEvents * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        END_INTERFACE
    } _ISimpleCOMObject_CPPImplEventsVtbl;

    interface _ISimpleCOMObject_CPPImplEvents
    {
        CONST_VTBL struct _ISimpleCOMObject_CPPImplEventsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _ISimpleCOMObject_CPPImplEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _ISimpleCOMObject_CPPImplEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _ISimpleCOMObject_CPPImplEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _ISimpleCOMObject_CPPImplEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _ISimpleCOMObject_CPPImplEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _ISimpleCOMObject_CPPImplEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _ISimpleCOMObject_CPPImplEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___ISimpleCOMObject_CPPImplEvents_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_SimpleCOMObject_CPPImpl;

#ifdef __cplusplus

class DECLSPEC_UUID("5E5F1A4A-3F76-4F07-946D-DF40E7B29C8B")
SimpleCOMObject_CPPImpl;
#endif
#endif /* __SimpleCOMObject_CPPImplLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


