// SimpleCOMObject_CPPImpl_.cpp : Implementation of CSimpleCOMObject_CPPImpl

#include "stdafx.h"
#include "SimpleCOMObject_CPPImpl_.h"


// CSimpleCOMObject_CPPImpl

STDMETHODIMP CSimpleCOMObject_CPPImpl::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ISimpleCOMObject_CPPImpl
	};

	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}
