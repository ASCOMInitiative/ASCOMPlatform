// SimpleCOMObject_CPPImpl_.h : Declaration of the CSimpleCOMObject_CPPImpl

#pragma once
#include "resource.h"       // main symbols

#include "SimpleCOMObject_CPPImpl.h"
#include "_ISimpleCOMObject_CPPImplEvents_CP.h"


// CSimpleCOMObject_CPPImpl

class ATL_NO_VTABLE CSimpleCOMObject_CPPImpl : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSimpleCOMObject_CPPImpl, &CLSID_SimpleCOMObject_CPPImpl>,
	public ISupportErrorInfo,
	public IConnectionPointContainerImpl<CSimpleCOMObject_CPPImpl>,
	public CProxy_ISimpleCOMObject_CPPImplEvents<CSimpleCOMObject_CPPImpl>, 
	public IDispatchImpl<ISimpleCOMObject_CPPImpl, &IID_ISimpleCOMObject_CPPImpl, &LIBID_SimpleCOMObject_CPPImplLib, /*wMajor =*/ 1, /*wMinor =*/ 0>,
	public IDispatchImpl<ISimpleCOMObject, &__uuidof(ISimpleCOMObject), &LIBID_SimpleCOMObjectLib, /* wMajor = */ 1, /* wMinor = */ 0>
{
public:
	CSimpleCOMObject_CPPImpl()
	{
	}

	~CSimpleCOMObject_CPPImpl()
	{
	}

	DECLARE_REGISTRY_RESOURCEID(IDR_SIMPLECOMOBJECT_CPPIMPL1)


	BEGIN_COM_MAP(CSimpleCOMObject_CPPImpl)
		COM_INTERFACE_ENTRY(ISimpleCOMObject_CPPImpl)
		COM_INTERFACE_ENTRY2(IDispatch, ISimpleCOMObject)
		COM_INTERFACE_ENTRY(ISupportErrorInfo)
		COM_INTERFACE_ENTRY(IConnectionPointContainer)
		COM_INTERFACE_ENTRY(ISimpleCOMObject)
	END_COM_MAP()

	BEGIN_CONNECTION_POINT_MAP(CSimpleCOMObject_CPPImpl)
		CONNECTION_POINT_ENTRY(__uuidof(_ISimpleCOMObject_CPPImplEvents))
	END_CONNECTION_POINT_MAP()
	// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
	    m_lLongProperty = 0;
		return S_OK;
	}

	void FinalRelease() 
	{
	}

public:

protected :
	// Member functions and data.
	long	m_lLongProperty;

	// ISimpleCOMObject Methods
public:
	STDMETHOD(get_LongProperty)(long * pVal)
	{
	    *pVal = m_lLongProperty;
	    
		return S_OK;
	}
	STDMETHOD(put_LongProperty)(long pVal)
	{
	    m_lLongProperty = pVal;
	    
		return S_OK;
	}
	STDMETHOD(Method01)(BSTR strMessage)
	{
	    std::string strTemp;
	    _bstr_t		_bstMessage(strMessage, true);
	    
	    strTemp.resize(256, 0);
	    
	    sprintf (&(strTemp[0]), "%s %d", (LPCTSTR)_bstMessage, m_lLongProperty);
	    
	    MessageBox (NULL, strTemp.c_str(), "SimpleCOMObject_CPPImpl", MB_OK);
	    
		return S_OK;
	}
};

OBJECT_ENTRY_AUTO(__uuidof(SimpleCOMObject_CPPImpl), CSimpleCOMObject_CPPImpl)
