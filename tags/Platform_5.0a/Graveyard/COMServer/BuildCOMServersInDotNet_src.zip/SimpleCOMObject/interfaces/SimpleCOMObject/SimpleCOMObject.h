

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 6.00.0361 */
/* at Thu Jan 05 00:55:16 2006
 */
/* Compiler settings for .\SimpleCOMObject.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __SimpleCOMObject_h__
#define __SimpleCOMObject_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __ISimpleCOMObject_FWD_DEFINED__
#define __ISimpleCOMObject_FWD_DEFINED__
typedef interface ISimpleCOMObject ISimpleCOMObject;
#endif 	/* __ISimpleCOMObject_FWD_DEFINED__ */


#ifndef ___ISimpleCOMObjectEvents_FWD_DEFINED__
#define ___ISimpleCOMObjectEvents_FWD_DEFINED__
typedef interface _ISimpleCOMObjectEvents _ISimpleCOMObjectEvents;
#endif 	/* ___ISimpleCOMObjectEvents_FWD_DEFINED__ */


#ifndef __SimpleCOMObject_FWD_DEFINED__
#define __SimpleCOMObject_FWD_DEFINED__

#ifdef __cplusplus
typedef class SimpleCOMObject SimpleCOMObject;
#else
typedef struct SimpleCOMObject SimpleCOMObject;
#endif /* __cplusplus */

#endif 	/* __SimpleCOMObject_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void * ); 

#ifndef __ISimpleCOMObject_INTERFACE_DEFINED__
#define __ISimpleCOMObject_INTERFACE_DEFINED__

/* interface ISimpleCOMObject */
/* [unique][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_ISimpleCOMObject;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("9EB07DC7-6807-4104-95FE-AD7672A87BD7")
    ISimpleCOMObject : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_LongProperty( 
            /* [retval][out] */ LONG *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_LongProperty( 
            /* [in] */ LONG newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Method01( 
            /* [in] */ BSTR strMessage) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISimpleCOMObjectVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISimpleCOMObject * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISimpleCOMObject * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISimpleCOMObject * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISimpleCOMObject * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISimpleCOMObject * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISimpleCOMObject * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISimpleCOMObject * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_LongProperty )( 
            ISimpleCOMObject * This,
            /* [retval][out] */ LONG *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_LongProperty )( 
            ISimpleCOMObject * This,
            /* [in] */ LONG newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Method01 )( 
            ISimpleCOMObject * This,
            /* [in] */ BSTR strMessage);
        
        END_INTERFACE
    } ISimpleCOMObjectVtbl;

    interface ISimpleCOMObject
    {
        CONST_VTBL struct ISimpleCOMObjectVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISimpleCOMObject_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISimpleCOMObject_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISimpleCOMObject_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISimpleCOMObject_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISimpleCOMObject_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISimpleCOMObject_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISimpleCOMObject_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISimpleCOMObject_get_LongProperty(This,pVal)	\
    (This)->lpVtbl -> get_LongProperty(This,pVal)

#define ISimpleCOMObject_put_LongProperty(This,newVal)	\
    (This)->lpVtbl -> put_LongProperty(This,newVal)

#define ISimpleCOMObject_Method01(This,strMessage)	\
    (This)->lpVtbl -> Method01(This,strMessage)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISimpleCOMObject_get_LongProperty_Proxy( 
    ISimpleCOMObject * This,
    /* [retval][out] */ LONG *pVal);


void __RPC_STUB ISimpleCOMObject_get_LongProperty_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISimpleCOMObject_put_LongProperty_Proxy( 
    ISimpleCOMObject * This,
    /* [in] */ LONG newVal);


void __RPC_STUB ISimpleCOMObject_put_LongProperty_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISimpleCOMObject_Method01_Proxy( 
    ISimpleCOMObject * This,
    /* [in] */ BSTR strMessage);


void __RPC_STUB ISimpleCOMObject_Method01_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISimpleCOMObject_INTERFACE_DEFINED__ */



#ifndef __SimpleCOMObjectLib_LIBRARY_DEFINED__
#define __SimpleCOMObjectLib_LIBRARY_DEFINED__

/* library SimpleCOMObjectLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_SimpleCOMObjectLib;

#ifndef ___ISimpleCOMObjectEvents_DISPINTERFACE_DEFINED__
#define ___ISimpleCOMObjectEvents_DISPINTERFACE_DEFINED__

/* dispinterface _ISimpleCOMObjectEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__ISimpleCOMObjectEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("164025E5-6837-4556-A234-3B563407AC38")
    _ISimpleCOMObjectEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _ISimpleCOMObjectEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            _ISimpleCOMObjectEvents * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            _ISimpleCOMObjectEvents * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            _ISimpleCOMObjectEvents * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            _ISimpleCOMObjectEvents * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            _ISimpleCOMObjectEvents * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            _ISimpleCOMObjectEvents * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            _ISimpleCOMObjectEvents * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        END_INTERFACE
    } _ISimpleCOMObjectEventsVtbl;

    interface _ISimpleCOMObjectEvents
    {
        CONST_VTBL struct _ISimpleCOMObjectEventsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _ISimpleCOMObjectEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _ISimpleCOMObjectEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _ISimpleCOMObjectEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _ISimpleCOMObjectEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _ISimpleCOMObjectEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _ISimpleCOMObjectEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _ISimpleCOMObjectEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___ISimpleCOMObjectEvents_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_SimpleCOMObject;

#ifdef __cplusplus

class DECLSPEC_UUID("25A6EEC9-6CA0-4B23-9251-7280A8781342")
SimpleCOMObject;
#endif
#endif /* __SimpleCOMObjectLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long *, unsigned long            , BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserMarshal(  unsigned long *, unsigned char *, BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserUnmarshal(unsigned long *, unsigned char *, BSTR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long *, BSTR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


