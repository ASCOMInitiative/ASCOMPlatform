// SimpleCOMObject_.cpp : Implementation of CSimpleCOMObject

#include "stdafx.h"
#include "SimpleCOMObject_.h"
#include ".\simplecomobject_.h"


// CSimpleCOMObject

STDMETHODIMP CSimpleCOMObject::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ISimpleCOMObject
	};

	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CSimpleCOMObject::get_LongProperty(LONG* pVal)
{
	// TODO: Add your implementation code here

	return S_OK;
}

STDMETHODIMP CSimpleCOMObject::put_LongProperty(LONG newVal)
{
	// TODO: Add your implementation code here

	return S_OK;
}

STDMETHODIMP CSimpleCOMObject::Method01(BSTR strMessage)
{
	// TODO: Add your implementation code here

	return S_OK;
}
