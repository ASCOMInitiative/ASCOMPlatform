// SimpleCOMObject_.h : Declaration of the CSimpleCOMObject

#pragma once
#include "resource.h"       // main symbols

#include "SimpleCOMObject.h"
#include "_ISimpleCOMObjectEvents_CP.h"


// CSimpleCOMObject

class ATL_NO_VTABLE CSimpleCOMObject : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSimpleCOMObject, &CLSID_SimpleCOMObject>,
	public ISupportErrorInfo,
	public IConnectionPointContainerImpl<CSimpleCOMObject>,
	public CProxy_ISimpleCOMObjectEvents<CSimpleCOMObject>, 
	public IDispatchImpl<ISimpleCOMObject, &IID_ISimpleCOMObject, &LIBID_SimpleCOMObjectLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:
	CSimpleCOMObject()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SIMPLECOMOBJECT1)


BEGIN_COM_MAP(CSimpleCOMObject)
	COM_INTERFACE_ENTRY(ISimpleCOMObject)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
END_COM_MAP()

BEGIN_CONNECTION_POINT_MAP(CSimpleCOMObject)
	CONNECTION_POINT_ENTRY(__uuidof(_ISimpleCOMObjectEvents))
END_CONNECTION_POINT_MAP()
// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

public:

	STDMETHOD(get_LongProperty)(LONG* pVal);
	STDMETHOD(put_LongProperty)(LONG newVal);
	STDMETHOD(Method01)(BSTR strMessage);
};

OBJECT_ENTRY_AUTO(__uuidof(SimpleCOMObject), CSimpleCOMObject)
