using System;
using ASCOM.Interface.Focuser;
using ASCOM.Helper;

namespace ASCOM
{
	class ClientTest
	{
		static void Main(string[] args)
		{
			Helper.Util U = new Helper.Util();
			// Could use Helper here but the Focuser Choose() is nice!
			string progID = Focuser.Choose("FocusSim.Focuser");
			if (progID == "") return;
			Focuser F = new Focuser(progID);
			F.Link = true;
			Console.WriteLine("Connected to " + progID);
			Console.WriteLine("Current position is " + F.Position);
			Console.Write("New position: ");
			string sNewPos = Console.ReadLine();
			F.Move(Convert.ToInt32(sNewPos));
			while (F.IsMoving)
			{
				Console.Write(".");
				U.WaitForMilliseconds(333);
			}
			Console.WriteLine("\r\nMove complete. New position is " + F.Position.ToString());
			F.Link = false;
			Console.Write("Press enter to quit");
			Console.ReadLine();
		}
	}
}
