using System;

namespace ASCOM.LocalServerCOM
{
	public class ReferenceCountedObjectBase
	{
		public ReferenceCountedObjectBase()
		{
			LocalServerCOM.Trace("ReferenceCountedObjectBase contructor.");
			LocalServerCOM.CountObject();
		}

		~ReferenceCountedObjectBase()
		{
			LocalServerCOM.Trace("ReferenceCountedObjectBase destructor.");
			LocalServerCOM.UncountObject();
			LocalServerCOM.ExitIf();
		}
	}
}
