using System;
using System.Runtime.InteropServices;

namespace ASCOM.LocalServerCOM
{

	#region C# Definition of IClassFactory
	//
	// Provide a definition of theCOM IClassFactory interface.
	//
	[
	  ComImport,												// This interface originated from COM.
	  ComVisible(false),										// Must not be exposed to COM!!!
	  InterfaceType(ComInterfaceType.InterfaceIsIUnknown),		// Indicate that this interface is not IDispatch-based.
	  Guid("00000001-0000-0000-C000-000000000046")				// This GUID is the actual GUID of IClassFactory.
	]
	public interface IClassFactory
	{
		void CreateInstance(IntPtr pUnkOuter, ref Guid riid, out IntPtr ppvObject);
		void LockServer(bool fLock);
	}
	#endregion

	//
	// Base class for ClassFactories of our served objects, 
	// of course it implements IClassFactory
	//
	internal class ClassFactoryBase : IClassFactory
	{

		#region Access to ole32.dll functions for class factories

		[Flags]
		enum CLSCTX : uint
		{
			CLSCTX_INPROC_SERVER = 0x1,
			CLSCTX_INPROC_HANDLER = 0x2,
			CLSCTX_LOCAL_SERVER = 0x4,
			CLSCTX_INPROC_SERVER16 = 0x8,
			CLSCTX_REMOTE_SERVER = 0x10,
			CLSCTX_INPROC_HANDLER16 = 0x20,
			CLSCTX_RESERVED1 = 0x40,
			CLSCTX_RESERVED2 = 0x80,
			CLSCTX_RESERVED3 = 0x100,
			CLSCTX_RESERVED4 = 0x200,
			CLSCTX_NO_CODE_DOWNLOAD = 0x400,
			CLSCTX_RESERVED5 = 0x800,
			CLSCTX_NO_CUSTOM_MARSHAL = 0x1000,
			CLSCTX_ENABLE_CODE_DOWNLOAD = 0x2000,
			CLSCTX_NO_FAILURE_LOG = 0x4000,
			CLSCTX_DISABLE_AAA = 0x8000,
			CLSCTX_ENABLE_AAA = 0x10000,
			CLSCTX_FROM_DEFAULT_CONTEXT = 0x20000,
			CLSCTX_INPROC = CLSCTX_INPROC_SERVER | CLSCTX_INPROC_HANDLER,
			CLSCTX_SERVER = CLSCTX_INPROC_SERVER | CLSCTX_LOCAL_SERVER | CLSCTX_REMOTE_SERVER,
			CLSCTX_ALL = CLSCTX_SERVER | CLSCTX_INPROC_HANDLER
		}

		[DllImport("ole32.dll")]
		static extern int CoRegisterClassObject(
			[In] ref Guid rclsid,
			[MarshalAs(UnmanagedType.IUnknown)] object pUnk, 
			uint dwClsContext,
			uint flags, 
			out uint lpdwRegister);

		[DllImport("ole32.dll")]
		static extern int CoResumeClassObjects();

		[DllImport("ole32.dll")]
		static extern int CoRevokeClassObject(uint dwRegister);
		
		#endregion

		#region Constructor and Private ClassFactory Data

		public ClassFactoryBase()
		{
		}

		protected UInt32	m_locked = 0;
		protected uint		m_ClassContext = (uint)CLSCTX.CLSCTX_LOCAL_SERVER;
		protected Guid		m_ClassId;
		protected uint		m_Flags;
		protected uint		m_Cookie;
		#endregion

		//
		// Inheriting real ClassFactories must override at least this. Each type
		// of object served by this server must have its own ClassFactory which
		// inherits and overrides this CreateInstance().
		//
		public virtual void CreateInstance(IntPtr pUnkOuter, ref Guid riid, out IntPtr ppvObject)
		{
			IntPtr nullPtr = new IntPtr(0);
			ppvObject = nullPtr;
		}

		#region Common ClassFactory Methods
		public uint ClassContext
		{
			get
			{
				return m_ClassContext;
			}
			set
			{
				m_ClassContext = value;
			}
		}

		public Guid ClassId
		{
			get
			{
				return m_ClassId;
			}
			set
			{
				m_ClassId = value;
			}
		}

		public uint Flags
		{
			get
			{
				return m_Flags;
			}
			set
			{
				m_Flags = value;
			}
		}

		public bool RegisterClassObject()
		{
			// Register the class factory
			int i = CoRegisterClassObject
				(
				ref m_ClassId, 
				this,
				ClassContext, 
				Flags,
				out m_Cookie
				);

			if (i == 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		public bool RevokeClassObject()
		{
			int i = CoRevokeClassObject(m_Cookie);

			if (i == 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		public static bool ResumeClassObjects()
		{
			int i = CoResumeClassObjects();

			if (i == 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		#endregion

		#region IClassFactory Implementations
		void IClassFactory.CreateInstance(IntPtr pUnkOuter, ref Guid riid, out IntPtr ppvObject)
		{
			CreateInstance(pUnkOuter, ref riid, out ppvObject);
		}

		void IClassFactory.LockServer(bool bLock)
		{
			if (bLock)
			{
				LocalServerCOM.CountLock();
			}
			else
			{
				LocalServerCOM.UncountLock();
			}

			// Always attempt to see if we need to shutdown this server application.
			LocalServerCOM.ExitIf();
		}
		#endregion
	}
}
