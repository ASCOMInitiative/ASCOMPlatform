var S1 = new ActiveXObject("DriverHelper.Serial");
S1.Port = 6;
S1.Connected = true;
var S2 = new ActiveXObject("DriverHelper.Serial");
S2.Port = 7;
S2.Connected = true;
