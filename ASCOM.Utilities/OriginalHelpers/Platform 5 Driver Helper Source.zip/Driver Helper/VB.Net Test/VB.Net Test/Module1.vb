Module Module1

    Sub Main()

		Dim U As New ASCOM.Helper.Util

		Debug.Print(U.FormatVar(1.234567, "0.00"))

    End Sub

End Module
