To install the Helper2 object, put it into C:\Progrm Files\Common
Files\ASCOM (next to the existing helper.dll). Then with a shell
register it

  regsvr32 helper2.dll

The enclosed CHM file documents the interface.


