var H2 = new ActiveXObject("DriverHelper2.Util");
WScript.Echo(H2.PlatformVersion);
