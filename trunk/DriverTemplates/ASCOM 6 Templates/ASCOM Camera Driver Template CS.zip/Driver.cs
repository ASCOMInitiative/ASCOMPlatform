//tabs=4
// --------------------------------------------------------------------------------
// TODO fill in this information for your driver, then remove this line!
//
// ASCOM Camera driver for $safeprojectname$
//
// Description:	Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam 
//				nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam 
//				erat, sed diam voluptua. At vero eos et accusam et justo duo 
//				dolores et ea rebum. Stet clita kasd gubergren, no sea takimata 
//				sanctus est Lorem ipsum dolor sit amet.
//
// Implements:	ASCOM Camera interface version: 1.0
// Author:		(XXX) Your N. Here <your@email.here>
//
// Edit Log:
//
// Date			Who	Vers	Description
// -----------	---	-----	-------------------------------------------------------
// dd-mmm-yyyy	XXX	1.0.0	Initial edit, from ASCOM Camera Driver template
// --------------------------------------------------------------------------------
//
using System;
using System.Collections;
using System.Runtime.InteropServices;
using ASCOM.DeviceInterface;
using ASCOM.Utilities;

namespace ASCOM.$safeprojectname$
{
	//
	// Your driver's ID is ASCOM.$safeprojectname$.Camera
	//
	// The Guid attribute sets the CLSID for ASCOM.$safeprojectname$.Camera
	// The ClassInterface/None addribute prevents an empty interface called
	// _Camera from being created and used as the [default] interface
	//
    [Guid("$guid2$")]
	[ClassInterface(ClassInterfaceType.None)]
    [ComVisible(true)]
    public class Camera : ICameraV2
    {
        #region Camera Constants
        //
        // Driver ID and descriptive string that shows in the Chooser
        //
        private const string driverId = "ASCOM.$safeprojectname$.Camera";
        // TODO Change the descriptive string for your driver then remove this line
        private const string driverDescription = "$safeprojectname$ Camera";
        #endregion

        #region ASCOM Registration
        //
        // Register or unregister driver for ASCOM. This is harmless if already
        // registered or unregistered. 
        //
        private static void RegUnregASCOM(bool bRegister)
        {
            var p = new Profile {DeviceType = "Camera"};
            if (bRegister)
                p.Register(driverId, driverDescription);
            else
                p.Unregister(driverId);
            try                        // In case Helper becomes native .NET
            {
                Marshal.ReleaseComObject(p);
            }
            catch (Exception) { }
        }

        [ComRegisterFunction]
        public static void RegisterASCOM(Type t)
        {
            RegUnregASCOM(true);
        }

        [ComUnregisterFunction]
        public static void UnregisterASCOM(Type t)
        {
            RegUnregASCOM(false);
        }
        #endregion

        #region Implementation of ICameraV2

        public void SetupDialog()
        {
            var f = new SetupDialogForm();
            f.ShowDialog();
        }

        public string Action(string actionName, string actionParameters)
        {
            throw new System.NotImplementedException();
        }

        public void CommandBlind(string command, bool raw)
        {
            throw new System.NotImplementedException();
        }

        public bool CommandBool(string command, bool raw)
        {
            throw new System.NotImplementedException();
        }

        public string CommandString(string command, bool raw)
        {
            throw new System.NotImplementedException();
        }

        public void Dispose()
        {
            throw new System.NotImplementedException();
        }

        public void AbortExposure()
        {
            throw new System.NotImplementedException();
        }

        public void PulseGuide(GuideDirections direction, int duration)
        {
            throw new System.NotImplementedException();
        }

        public void StartExposure(double duration, bool light)
        {
            throw new System.NotImplementedException();
        }

        public void StopExposure()
        {
            throw new System.NotImplementedException();
        }

        public bool Connected
        {
            get { throw new System.NotImplementedException(); }
            set { throw new System.NotImplementedException(); }
        }

        public string Description
        {
            get { throw new System.NotImplementedException(); }
        }

        public string DriverInfo
        {
            get { throw new System.NotImplementedException(); }
        }

        public string DriverVersion
        {
            get { throw new System.NotImplementedException(); }
        }

        public short InterfaceVersion
        {
            get { throw new System.NotImplementedException(); }
        }

        public string Name
        {
            get { throw new System.NotImplementedException(); }
        }

        public ArrayList SupportedActions
        {
            get { throw new System.NotImplementedException(); }
        }

        public short BinX
        {
            get { throw new System.NotImplementedException(); }
            set { throw new System.NotImplementedException(); }
        }

        public short BinY
        {
            get { throw new System.NotImplementedException(); }
            set { throw new System.NotImplementedException(); }
        }

        public CameraStates CameraState
        {
            get { throw new System.NotImplementedException(); }
        }

        public int CameraXSize
        {
            get { throw new System.NotImplementedException(); }
        }

        public int CameraYSize
        {
            get { throw new System.NotImplementedException(); }
        }

        public bool CanAbortExposure
        {
            get { throw new System.NotImplementedException(); }
        }

        public bool CanAsymmetricBin
        {
            get { throw new System.NotImplementedException(); }
        }

        public bool CanGetCoolerPower
        {
            get { throw new System.NotImplementedException(); }
        }

        public bool CanPulseGuide
        {
            get { throw new System.NotImplementedException(); }
        }

        public bool CanSetCCDTemperature
        {
            get { throw new System.NotImplementedException(); }
        }

        public bool CanStopExposure
        {
            get { throw new System.NotImplementedException(); }
        }

        public double CCDTemperature
        {
            get { throw new System.NotImplementedException(); }
        }

        public bool CoolerOn
        {
            get { throw new System.NotImplementedException(); }
            set { throw new System.NotImplementedException(); }
        }

        public double CoolerPower
        {
            get { throw new System.NotImplementedException(); }
        }

        public double ElectronsPerADU
        {
            get { throw new System.NotImplementedException(); }
        }

        public double FullWellCapacity
        {
            get { throw new System.NotImplementedException(); }
        }

        public bool HasShutter
        {
            get { throw new System.NotImplementedException(); }
        }

        public double HeatSinkTemperature
        {
            get { throw new System.NotImplementedException(); }
        }

        public object ImageArray
        {
            get { throw new System.NotImplementedException(); }
        }

        public object ImageArrayVariant
        {
            get { throw new System.NotImplementedException(); }
        }

        public bool ImageReady
        {
            get { throw new System.NotImplementedException(); }
        }

        public bool IsPulseGuiding
        {
            get { throw new System.NotImplementedException(); }
        }

        public double LastExposureDuration
        {
            get { throw new System.NotImplementedException(); }
        }

        public string LastExposureStartTime
        {
            get { throw new System.NotImplementedException(); }
        }

        public int MaxADU
        {
            get { throw new System.NotImplementedException(); }
        }

        public short MaxBinX
        {
            get { throw new System.NotImplementedException(); }
        }

        public short MaxBinY
        {
            get { throw new System.NotImplementedException(); }
        }

        public int NumX
        {
            get { throw new System.NotImplementedException(); }
            set { throw new System.NotImplementedException(); }
        }

        public int NumY
        {
            get { throw new System.NotImplementedException(); }
            set { throw new System.NotImplementedException(); }
        }

        public double PixelSizeX
        {
            get { throw new System.NotImplementedException(); }
        }

        public double PixelSizeY
        {
            get { throw new System.NotImplementedException(); }
        }

        public double SetCCDTemperature
        {
            get { throw new System.NotImplementedException(); }
            set { throw new System.NotImplementedException(); }
        }

        public int StartX
        {
            get { throw new System.NotImplementedException(); }
            set { throw new System.NotImplementedException(); }
        }

        public int StartY
        {
            get { throw new System.NotImplementedException(); }
            set { throw new System.NotImplementedException(); }
        }

        public short BayerOffsetX
        {
            get { throw new System.NotImplementedException(); }
        }

        public short BayerOffsetY
        {
            get { throw new System.NotImplementedException(); }
        }

        public bool CanFastReadout
        {
            get { throw new System.NotImplementedException(); }
        }

        public double ExposureMax
        {
            get { throw new System.NotImplementedException(); }
        }

        public double ExposureMin
        {
            get { throw new System.NotImplementedException(); }
        }

        public double ExposureResolution
        {
            get { throw new System.NotImplementedException(); }
        }

        public bool FastReadout
        {
            get { throw new System.NotImplementedException(); }
            set { throw new System.NotImplementedException(); }
        }

        public short Gain
        {
            get { throw new System.NotImplementedException(); }
            set { throw new System.NotImplementedException(); }
        }

        public short GainMax
        {
            get { throw new System.NotImplementedException(); }
        }

        public short GainMin
        {
            get { throw new System.NotImplementedException(); }
        }

        public string[] Gains
        {
            get { throw new System.NotImplementedException(); }
        }

        public short PercentCompleted
        {
            get { throw new System.NotImplementedException(); }
        }

        public short ReadoutMode
        {
            get { throw new System.NotImplementedException(); }
        }

        public string[] ReadoutModes
        {
            get { throw new System.NotImplementedException(); }
        }

        public string SensorName
        {
            get { throw new System.NotImplementedException(); }
        }

        public SensorType SensorType
        {
            get { throw new System.NotImplementedException(); }
        }

        #endregion
    }
}
